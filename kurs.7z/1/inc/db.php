<?php

    $connect = mysqli_connect('localhost','root','','19080_kurs');

    if (!$connect){
        die('error yayayayaya');
    }
