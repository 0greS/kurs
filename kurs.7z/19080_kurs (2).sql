-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 08 2022 г., 15:49
-- Версия сервера: 10.4.27-MariaDB
-- Версия PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `19080_kurs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `korz`
--

CREATE TABLE `korz` (
  `id_zak` int(11) NOT NULL,
  `name_tov` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `pic` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `tovar`
--

CREATE TABLE `tovar` (
  `id_tovar` int(11) NOT NULL,
  `name_tov` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `pic` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `tovar`
--

INSERT INTO `tovar` (`id_tovar`, `name_tov`, `price`, `type`, `pic`) VALUES
(47, 'Logitech G102', 3299, 'Мышь', 'img/g102.jpg'),
(48, 'Logitech G PRO Wireless', 10000, 'Мышь', 'img/gpro.jpg'),
(49, 'RAZER VIPER ULTIMATE', 10000, 'Мышь', 'img/razer.jpg'),
(50, 'HYPER X CLOUD 2', 6500, 'Наушники', 'img/clud2.jpg'),
(51, 'Logitech G PRO X', 12500, 'Наушники', 'img/gprox.jpg'),
(52, 'RAZER KITTY', 9000, 'Наушники', 'img/kitty.jpg'),
(53, 'Logitech G Pro', 15000, 'Клавиатура', 'img/gproklc.webp'),
(54, 'Razer BlackWidow V3 Pro', 16000, 'Клавиатура', 'img/razerblack.webp'),
(55, 'HyperX Alloy Elite 2', 14000, 'Клавиатура', 'img/hyperxklav.webp');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `telephone` int(12) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id_user`, `name`, `telephone`, `pass`, `mail`) VALUES
(1, 'Валенок', 123456, 'e10adc3949ba59abbe56e057f20f883e', 'sergo38erbg@gmail.com'),
(16, 'admin', 2147483647, 'e00cf25ad42683b3df678c61f42c6bda', 'admin@admin.admin'),
(17, 'Валенок', 123456, 'e10adc3949ba59abbe56e057f20f883e', 'sergo38erbg@gmail.com');

-- --------------------------------------------------------

--
-- Структура таблицы `zakaz`
--

CREATE TABLE `zakaz` (
  `id_zakaz` int(11) NOT NULL,
  `sum` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `zakaz`
--

INSERT INTO `zakaz` (`id_zakaz`, `sum`) VALUES
(9, 129000),
(10, 35000),
(11, 32500);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `korz`
--
ALTER TABLE `korz`
  ADD PRIMARY KEY (`id_zak`) USING BTREE;

--
-- Индексы таблицы `tovar`
--
ALTER TABLE `tovar`
  ADD PRIMARY KEY (`id_tovar`) USING BTREE;

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Индексы таблицы `zakaz`
--
ALTER TABLE `zakaz`
  ADD PRIMARY KEY (`id_zakaz`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `korz`
--
ALTER TABLE `korz`
  MODIFY `id_zak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT для таблицы `tovar`
--
ALTER TABLE `tovar`
  MODIFY `id_tovar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `zakaz`
--
ALTER TABLE `zakaz`
  MODIFY `id_zakaz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
