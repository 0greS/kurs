<?php

    session_start();
    require_once 'db.php';

    $message = $_POST['message'];
    $username = $_POST['username'];
    $telephone = $_POST['telephone'];
    $pass = $_POST['pass'];
    $email = $_POST['email'];
    $pass_confirm = $_POST['pass_confirm'];

    if ($pass === $pass_confirm){

        $pass = md5($pass);

        mysqli_query($connect,"INSERT INTO `user` (`id_user`, `name`, `telephone`, `pass`, `mail`) VALUES ('', '$username', '$telephone', '$pass', '$email')");

        $_SESSION['message'] = 'Регистрация прошла успешно!';
        header('Location: ../log.php');

    } else{
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location: ../reg.php');
    }

?>



