<?php

    session_start();
    require_once 'db.php';

    $username = $_POST['username'];
    $pass = md5($_POST['pass']);
    $email = $_POST['email'];

    $check_user = mysqli_query($connect,"SELECT * FROM `user` where `name` = '$username' and `pass`='$pass' and `mail`='$email'");

    if (mysqli_num_rows($check_user) > 0){

        $user = mysqli_fetch_assoc($check_user);

        $_SESSION['user'] = [
            "id" =>$user['id'],
            "user_name" => $user['user_name'],
            "email" => $user['email']
        ];
        header('Location: ../index1.php');

    }else{
        $_SESSION['message'] = 'Введены неверные данные';
        header('Location: ../log.php');
    }
    ?>
<pre>
    <?php
print_r($check_user);
print_r($user);
    ?>
</pre>