<?php
require_once 'db.php';

$name = $_POST['name'];
$price = $_POST['price'];
$type = $_POST['type'];

mysqli_query($connect,"INSERT INTO `tovar` (`id_tovar`, `name_tov`, `price`, `type`) VALUES (NULL, '$name', '$price', '$type')");

header('Location: ../adminka.php');