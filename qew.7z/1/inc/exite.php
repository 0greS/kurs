<?php
session_start();

$_SESSION['message1']=false;
header('Location: ../index.php');