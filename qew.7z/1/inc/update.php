<?php
require_once 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$type = $_POST['type'];

mysqli_query($connect,"UPDATE `tovar` SET `name_tov` = '$name', `price` = '$price', `type` = '$price' WHERE `tovar`.`id_tovar` = '$id';");

header('Location: ../adminka.php');